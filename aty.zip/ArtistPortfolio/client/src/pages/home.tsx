import Navigation from "@/components/navigation";
import Hero from "@/components/hero";
import FeaturedGallery from "@/components/featured-gallery";
import Gallery from "@/components/gallery";
import About from "@/components/about";
import Contact from "@/components/contact";
import Footer from "@/components/footer";
import ImageModal, { openImageModal } from "@/components/image-modal";

export default function Home() {
  const handleImageClick = (artwork: any) => {
    openImageModal(artwork.imageUrl, artwork.title);
  };

  return (
    <div className="bg-white font-inter text-charcoal">
      <Navigation />
      <Hero />
      <FeaturedGallery onImageClick={handleImageClick} />
      <Gallery onImageClick={handleImageClick} />
      <About />
      <Contact />
      <Footer />
      <ImageModal />
    </div>
  );
}
