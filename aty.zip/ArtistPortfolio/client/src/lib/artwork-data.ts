// Import artwork images
import demonSlayerImg from "@assets/Screenshot_20240829_102435_Gallery_1752144578315.jpg";
import crownStudyImg from "@assets/IMG-20250228-WA0005_1752144584034.jpg";
import animePortraitImg from "@assets/IMG-20250228-WA0072_1752144587152.jpg";
import lostCharacterImg from "@assets/Screenshot_20240829_102450_Gallery_1752144606527.jpg";
import elephantStudyImg from "@assets/IMG-20250228-WA0022_1752144627029.jpg";
import handFlowerImg from "@assets/IMG-20250228-WA0024_1752144645905.jpg";
import skylineCarImg from "@assets/IMG-20250228-WA0026_1752144661021.jpg";
import animeCloseupImg from "@assets/IMG-20250228-WA0035_1752144682314.jpg";

export interface ArtworkItem {
  id: string;
  title: string;
  medium: string;
  year: string;
  category: 'portraits' | 'studies' | 'commissioned';
  imageUrl: string;
  description?: string;
}

export const featuredWorks: ArtworkItem[] = [
  {
    id: 'featured-1',
    title: 'Demon Slayer Character',
    medium: 'Ink on paper',
    year: '2024',
    category: 'portraits',
    imageUrl: demonSlayerImg,
    description: 'Detailed character portrait with intricate line work and shading'
  },
  {
    id: 'featured-2',
    title: 'Anime Character Portrait',
    medium: 'Colored pencil on paper',
    year: '2024',
    category: 'portraits',
    imageUrl: animePortraitImg,
    description: 'Vibrant anime-style character with blue hair and detailed coloring'
  },
  {
    id: 'featured-3',
    title: 'The Lost - Character Study',
    medium: 'Ink on paper',
    year: '2024',
    category: 'studies',
    imageUrl: lostCharacterImg,
    description: 'Expressive character study with Japanese text and emotional depth'
  }
];

export const galleryItems: ArtworkItem[] = [
  {
    id: 'gallery-1',
    title: 'Demon Slayer Character',
    medium: 'Ink on paper',
    year: '2024',
    category: 'portraits',
    imageUrl: demonSlayerImg,
    description: 'Detailed character portrait with intricate line work and shading'
  },
  {
    id: 'gallery-2',
    title: 'Royal Crown Study',
    medium: 'Pencil on lined paper',
    year: '2024',
    category: 'studies',
    imageUrl: crownStudyImg,
    description: 'Detailed study of a decorative crown with precise shading'
  },
  {
    id: 'gallery-3',
    title: 'Anime Character Portrait',
    medium: 'Colored pencil on paper',
    year: '2024',
    category: 'portraits',
    imageUrl: animePortraitImg,
    description: 'Vibrant anime-style character with blue hair and detailed coloring'
  },
  {
    id: 'gallery-4',
    title: 'The Lost - Character Study',
    medium: 'Ink on paper',
    year: '2024',
    category: 'studies',
    imageUrl: lostCharacterImg,
    description: 'Expressive character study with Japanese text and emotional depth'
  },
  {
    id: 'gallery-5',
    title: 'Elephant and Botanical Study',
    medium: 'Pencil on paper',
    year: '2024',
    category: 'studies',
    imageUrl: elephantStudyImg,
    description: 'Detailed elephant study combined with botanical elements'
  },
  {
    id: 'gallery-6',
    title: 'Hand with Flower',
    medium: 'Pencil on paper',
    year: '2024',
    category: 'studies',
    imageUrl: handFlowerImg,
    description: 'Expressive hand study holding a delicate flower'
  },
  {
    id: 'gallery-7',
    title: 'Skyline R34 GTR',
    medium: 'Ink and colored pencil',
    year: '2024',
    category: 'commissioned',
    imageUrl: skylineCarImg,
    description: 'Detailed automotive illustration of the iconic Nissan Skyline R34'
  },
  {
    id: 'gallery-8',
    title: 'Anime Character Close-up',
    medium: 'Pencil on toned paper',
    year: '2024',
    category: 'portraits',
    imageUrl: animeCloseupImg,
    description: 'Subtle character portrait with clean line work on toned paper'
  }
];
