export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-black text-gray-400 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="font-playfair text-xl font-semibold text-white mb-4">Aty</div>
            <p className="text-sm leading-relaxed">
              Professional artist creating detailed drawings that capture the essence and emotion of every subject.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold text-white mb-4">Quick Links</h3>
            <div className="space-y-2 text-sm">
              <button 
                onClick={() => scrollToSection('home')}
                className="block hover:text-gold transition-colors duration-300"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('gallery')}
                className="block hover:text-gold transition-colors duration-300"
              >
                Gallery
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="block hover:text-gold transition-colors duration-300"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="block hover:text-gold transition-colors duration-300"
              >
                Contact
              </button>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-white mb-4">Services</h3>
            <div className="space-y-2 text-sm">
              <div>Custom Portraits</div>
              <div>Pet Portraits</div>
              <div>Figure Studies</div>
              <div>Art Commissions</div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm">
          <p>&copy; 2024 Aty. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
