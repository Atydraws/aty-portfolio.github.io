import { useState, useEffect } from "react";
import { X } from "lucide-react";

interface ImageModalProps {
  isOpen?: boolean;
  imageSrc?: string;
  title?: string;
  onClose?: () => void;
}

let globalModalState = {
  isOpen: false,
  imageSrc: '',
  title: '',
  onClose: () => {}
};

let modalStateListeners: Array<(state: typeof globalModalState) => void> = [];

export function openImageModal(imageSrc: string, title: string) {
  globalModalState = {
    isOpen: true,
    imageSrc,
    title,
    onClose: closeImageModal
  };
  modalStateListeners.forEach(listener => listener(globalModalState));
  document.body.style.overflow = 'hidden';
}

export function closeImageModal() {
  globalModalState = {
    ...globalModalState,
    isOpen: false
  };
  modalStateListeners.forEach(listener => listener(globalModalState));
  document.body.style.overflow = 'auto';
}

export default function ImageModal() {
  const [modalState, setModalState] = useState(globalModalState);

  useEffect(() => {
    modalStateListeners.push(setModalState);
    return () => {
      const index = modalStateListeners.indexOf(setModalState);
      if (index > -1) {
        modalStateListeners.splice(index, 1);
      }
    };
  }, []);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && modalState.isOpen) {
        closeImageModal();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [modalState.isOpen]);

  if (!modalState.isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-90 z-[1000] flex items-center justify-center p-4"
      onClick={closeImageModal}
    >
      <button 
        onClick={closeImageModal}
        className="absolute top-4 right-4 text-white text-3xl hover:text-gold transition-colors duration-300 z-10"
      >
        <X size={32} />
      </button>
      
      <div className="relative max-w-[90vw] max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
        <img 
          src={modalState.imageSrc} 
          alt={modalState.title}
          className="max-w-full max-h-full object-contain"
        />
        
        {modalState.title && (
          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-75 text-white p-4 text-center">
            <div className="font-playfair text-lg">{modalState.title}</div>
          </div>
        )}
      </div>
    </div>
  );
}
