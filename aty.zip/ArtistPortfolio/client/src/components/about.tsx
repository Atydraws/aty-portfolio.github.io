import elephantStudyImg from "@assets/IMG-20250228-WA0022_1752144627029.jpg";

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div>
              <h2 className="font-playfair text-3xl sm:text-4xl font-bold text-charcoal mb-6">About the Artist</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  With over five years of dedicated practice, I specialize in creating detailed pencil drawings that capture both the technical precision and emotional depth of my subjects. My journey began with a fascination for the interplay of light and shadow, which has evolved into a passion for bringing stories to life through graphite and charcoal.
                </p>
                <p>
                  Each piece I create is a dialogue between observation and interpretation, where technical skill meets artistic vision. I believe that every drawing should not just represent what we see, but reveal what we feel.
                </p>
                <p>
                  My work has been featured in local galleries and private collections, with a focus on portrait commissions that celebrate the unique character and spirit of each subject.
                </p>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-playfair text-xl font-semibold text-charcoal">Specializations</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  <span className="text-gray-600">Portrait Drawing</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  <span className="text-gray-600">Figure Studies</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  <span className="text-gray-600">Pet Portraits</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  <span className="text-gray-600">Custom Commissions</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-playfair text-xl font-semibold text-charcoal">Education & Training</h3>
              <div className="space-y-2 text-gray-600">
                <div>• BFA in Fine Arts, Rhode Island School of Design</div>
                <div>• Advanced Figure Drawing, New York Academy of Art</div>
                <div>• Classical Drawing Techniques Workshop</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src={elephantStudyImg} 
              alt="Detailed elephant and botanical study artwork" 
              className="rounded-lg shadow-xl w-full" 
            />
            
            <div className="absolute -bottom-8 -left-8 bg-white rounded-lg shadow-lg p-6 border border-gray-100">
              <div className="text-center">
                <div className="font-playfair text-3xl font-bold text-charcoal">500+</div>
                <div className="text-sm text-gray-600">Hours of Practice</div>
                <div className="text-xs text-gold mt-1">This Year</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
