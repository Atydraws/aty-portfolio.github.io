import { ArrowRight } from "lucide-react";
import { featuredWorks } from "@/lib/artwork-data";

interface FeaturedGalleryProps {
  onImageClick?: (artwork: any) => void;
}

export default function FeaturedGallery({ onImageClick }: FeaturedGalleryProps) {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  const handleImageClick = (artwork: any) => {
    if (onImageClick) {
      onImageClick(artwork);
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-3xl sm:text-4xl font-bold text-charcoal mb-4">Featured Works</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            A selection of my most cherished pieces, each representing a journey of creativity and technical mastery.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredWorks.map((work) => (
            <div key={work.id} className="group cursor-pointer" onClick={() => handleImageClick(work)}>
              <div className="relative">
                <img 
                  src={work.imageUrl} 
                  alt={work.title} 
                  className="w-full h-80 object-cover rounded-lg shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-105" 
                />
                <div className="artwork-hover-overlay">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </div>
              </div>
              <div className="mt-4">
                <h3 className="font-playfair text-xl font-semibold text-charcoal">{work.title}</h3>
                <p className="text-gray-600 text-sm">{work.medium}, {work.year}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <button 
            onClick={() => scrollToSection('gallery')}
            className="inline-flex items-center px-8 py-3 bg-gold text-white font-medium rounded-lg hover:bg-yellow-600 transition-all duration-300 transform hover:scale-105"
          >
            View Full Gallery
            <ArrowRight className="ml-2" size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
