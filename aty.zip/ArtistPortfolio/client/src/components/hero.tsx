import { ArrowRight } from "lucide-react";
import demonSlayerImg from "@assets/Screenshot_20240829_102435_Gallery_1752144578315.jpg";
import animePortraitImg from "@assets/IMG-20250228-WA0072_1752144587152.jpg";
import crownStudyImg from "@assets/IMG-20250228-WA0005_1752144584034.jpg";
import lostCharacterImg from "@assets/Screenshot_20240829_102450_Gallery_1752144606527.jpg";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="pt-16 min-h-screen flex items-center bg-gradient-to-br from-light-gray to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h1 className="font-playfair text-4xl sm:text-5xl lg:text-6xl font-bold text-charcoal leading-tight">
                Bringing Ideas to <span className="text-gold">Life</span> Through Art
              </h1>
              <p className="mt-6 text-lg sm:text-xl text-gray-600 leading-relaxed">
                Professional illustrator specializing in detailed pencil drawings, digital art, and commissioned portraits. Every piece tells a unique story.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => scrollToSection('gallery')}
                className="inline-flex items-center justify-center px-8 py-3 bg-charcoal text-white font-medium rounded-lg hover:bg-gray-800 transition-all duration-300 transform hover:scale-105"
              >
                View Portfolio
                <ArrowRight className="ml-2" size={16} />
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="inline-flex items-center justify-center px-8 py-3 border-2 border-gold text-gold font-medium rounded-lg hover:bg-gold hover:text-white transition-all duration-300"
              >
                Commission Work
              </button>
            </div>
            
            <div className="flex items-center space-x-8 pt-4">
              <div className="text-center">
                <div className="font-playfair text-2xl font-bold text-charcoal">150+</div>
                <div className="text-sm text-gray-600">Artworks</div>
              </div>
              <div className="text-center">
                <div className="font-playfair text-2xl font-bold text-charcoal">50+</div>
                <div className="text-sm text-gray-600">Happy Clients</div>
              </div>
              <div className="text-center">
                <div className="font-playfair text-2xl font-bold text-charcoal">5</div>
                <div className="text-sm text-gray-600">Years Experience</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <img 
                src={demonSlayerImg} 
                alt="Demon Slayer character drawing" 
                className="rounded-lg shadow-lg w-full h-64 object-cover" 
              />
              <img 
                src={crownStudyImg} 
                alt="Crown study drawing" 
                className="rounded-lg shadow-lg w-full h-32 object-cover mt-8" 
              />
              <img 
                src={animePortraitImg} 
                alt="Anime character portrait" 
                className="rounded-lg shadow-lg w-full h-32 object-cover" 
              />
              <img 
                src={lostCharacterImg} 
                alt="The Lost character study" 
                className="rounded-lg shadow-lg w-full h-64 object-cover -mt-8" 
              />
            </div>
            
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-gold/20 rounded-full blur-xl"></div>
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-charcoal/10 rounded-full blur-2xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
