# Deployment Guide

This guide covers different deployment options for Aty's Artist Portfolio.

## Table of Contents

1. [GitHub Pages](#github-pages)
2. [Vercel](#vercel)
3. [Netlify](#netlify)
4. [Replit](#replit)
5. [Environment Variables](#environment-variables)

## GitHub Pages

### Automatic Deployment

1. **Enable GitHub Pages:**
   - Go to your repository settings
   - Scroll to "Pages" section
   - Select "GitHub Actions" as source

2. **Push to main branch:**
   - The GitHub Actions workflow will automatically build and deploy
   - Your site will be available at `https://[username].github.io/[repository-name]`

### Manual Deployment

1. **Build the project:**
   ```bash
   npm run build
   ```

2. **Deploy to GitHub Pages:**
   ```bash
   npm install -g gh-pages
   gh-pages -d dist/public
   ```

## Vercel

### Via GitHub Integration

1. **Connect to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Configure build settings:
     - Build Command: `npm run build`
     - Output Directory: `dist/public`
     - Install Command: `npm install`

2. **Environment Variables:**
   - Add `DATABASE_URL` if using PostgreSQL
   - Add `NODE_ENV=production`

### Via CLI

1. **Install Vercel CLI:**
   ```bash
   npm install -g vercel
   ```

2. **Deploy:**
   ```bash
   vercel --prod
   ```

## Netlify

### Via GitHub Integration

1. **Connect to Netlify:**
   - Go to [netlify.com](https://netlify.com)
   - Connect your GitHub repository
   - Configure build settings:
     - Build Command: `npm run build`
     - Publish Directory: `dist/public`

2. **Environment Variables:**
   - Add `DATABASE_URL` if using PostgreSQL
   - Add `NODE_ENV=production`

### Via CLI

1. **Install Netlify CLI:**
   ```bash
   npm install -g netlify-cli
   ```

2. **Deploy:**
   ```bash
   netlify deploy --prod --dir=dist/public
   ```

## Replit

### Development
- The project is optimized for Replit
- Simply click "Run" to start the development server
- Available at the provided Replit URL

### Production
- Use the "Deploy" button in Replit
- Configure as a static site pointing to `dist/public`

## Environment Variables

### Required Variables

- `DATABASE_URL`: PostgreSQL connection string
- `NODE_ENV`: Set to "production" for production builds

### Optional Variables

- `VITE_API_URL`: API base URL (defaults to same origin)

### Example .env file

```env
DATABASE_URL=postgresql://user:password@host:port/database
NODE_ENV=production
```

## Build Process

The build process creates:
- `dist/public/` - Frontend static files
- `dist/index.js` - Backend server (for full-stack deployments)

### Static-Only Deployment

For static-only deployments (GitHub Pages, Netlify, Vercel):
- Only deploy the `dist/public` folder
- Contact form will need a separate backend service

### Full-Stack Deployment

For full-stack deployments (Railway, Render, Heroku):
- Deploy the entire `dist/` folder
- Set up PostgreSQL database
- Configure environment variables

## Database Setup

### PostgreSQL

1. **Create a PostgreSQL database**
2. **Set DATABASE_URL environment variable**
3. **Run database migrations:**
   ```bash
   npm run db:push
   ```

### Serverless Options

- **Neon**: PostgreSQL-compatible serverless database
- **PlanetScale**: MySQL-compatible serverless database
- **Supabase**: PostgreSQL with additional features

## Troubleshooting

### Build Errors

1. **Node.js version**: Ensure Node.js 18+ is being used
2. **Dependencies**: Run `npm ci` to install exact versions
3. **TypeScript**: Check for TypeScript errors with `npm run check`

### Runtime Errors

1. **Environment variables**: Verify all required variables are set
2. **Database connection**: Check DATABASE_URL format
3. **Asset paths**: Ensure all images are properly imported

### Performance Optimization

1. **Image optimization**: Consider using WebP format for images
2. **Code splitting**: Vite handles this automatically
3. **Caching**: Configure appropriate cache headers

## Contact

For deployment assistance:
- Email: atyportofolio@gmail.com