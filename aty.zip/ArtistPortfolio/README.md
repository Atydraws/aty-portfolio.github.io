# Aty - Artist Portfolio

A professional portfolio website showcasing detailed pencil drawings, anime-style portraits, and custom illustrations.

## Features

- **Professional Gallery**: Masonry-style grid layout with filtering by category (Portraits, Studies, Commissioned)
- **Interactive Image Modal**: Full-screen image viewer with keyboard navigation (ESC to close)
- **Contact Form**: Functional contact form with backend API and form validation
- **Responsive Design**: Mobile-first design that works on all devices
- **Smooth Navigation**: Animated scrolling between sections
- **SEO Optimized**: Meta tags, Open Graph, and Twitter Card support

## Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + ShadCN UI Components
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state
- **Icons**: Lucide React
- **Fonts**: Playfair Display (headings) + Inter (body)

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd portfolio-website
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:5000](http://localhost:5000) to view the website

## Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run db:push` - Push database schema changes

## Project Structure

```
├── client/              # React frontend
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── pages/       # Page components
│   │   ├── lib/         # Utilities and data
│   │   └── hooks/       # Custom React hooks
├── server/              # Express.js backend
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API routes
│   └── storage.ts       # Data storage layer
├── shared/              # Shared TypeScript types
└── README.md
```

## Features in Detail

### Gallery System
- Three categories: Portraits, Studies, Commissioned works
- Masonry layout for optimal space usage
- Click to view full-size images in modal
- Smooth hover effects and transitions

### Contact Form
- Client-side and server-side validation
- Form fields: First Name, Last Name, Email, Subject, Message
- Toast notifications for success/error states
- Email contact information displayed

### Responsive Design
- Mobile-first approach
- Breakpoints: sm (640px), md (768px), lg (1024px), xl (1280px)
- Touch-friendly navigation on mobile devices

## Customization

### Adding New Artwork
Edit `client/src/lib/artwork-data.ts` to add new pieces:

```typescript
export const galleryItems: ArtworkItem[] = [
  {
    id: 'unique-id',
    title: 'Artwork Title',
    medium: 'Graphite on paper',
    year: '2024',
    category: 'portraits', // 'portraits' | 'studies' | 'commissioned'
    imageUrl: 'https://your-image-url.com/image.jpg'
  },
  // ... more items
];
```

### Styling
- Colors defined in `client/src/index.css` using CSS custom properties
- Primary palette: Charcoal (#2D2D2D), Gold (#C9A96E), Light Gray (#F8F8F8)
- Custom Tailwind classes available for consistent theming

### Contact Information
Update contact details in `client/src/components/contact.tsx`

## Deployment

### Replit
This project is optimized for Replit deployment:
1. Fork the repository on Replit
2. Install dependencies automatically
3. Click "Run" to start the development server

### Other Platforms
For deployment on Vercel, Netlify, or similar:
1. Build the project: `npm run build`
2. Deploy the `dist/` directory
3. Set environment variables if using a database

## Environment Variables

- `DATABASE_URL` - PostgreSQL connection string (optional, uses in-memory storage by default)
- `NODE_ENV` - Set to "production" for production builds

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Contact

For questions about this portfolio template or commissioning artwork:
- Email: atyportofolio@gmail.com

---

*Built with ❤️ using React, TypeScript, and Tailwind CSS*