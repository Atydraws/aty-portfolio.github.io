# replit.md

## Overview

This is a portfolio website for an artist specializing in pencil drawings and illustrations. The application is built as a full-stack web application with a React frontend and Express.js backend, designed to showcase artwork, handle contact form submissions, and provide an elegant user experience for potential clients.

## Recent Changes

- **January 2025**: Added PostgreSQL database integration with persistent storage for contact messages
- **January 2025**: Integrated 8 authentic artwork pieces including anime-style character portraits, botanical studies, crown sketch, and automotive illustration  
- **January 2025**: Updated hero section, about section, and gallery to display real artwork instead of placeholder images
- **January 2025**: All artwork now properly imported using Vite asset imports for optimal performance
- **January 2025**: Made portfolio GitHub-ready with proper deployment configuration
- **January 2025**: Updated contact information to show only name (Aty) and email (atyportofolio@gmail.com)
- **January 2025**: Created GitHub Actions workflow for automated deployment
- **January 2025**: Added comprehensive deployment documentation for multiple platforms

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between frontend (client), backend (server), and shared components. It uses a modern TypeScript-based stack with React for the frontend and Express.js for the backend, with PostgreSQL as the database layer managed through Drizzle ORM.

### Directory Structure
- `client/` - React frontend application with ShadCN UI components
- `server/` - Express.js backend with API routes
- `shared/` - Shared TypeScript types and database schema
- `components.json` - ShadCN UI configuration
- Various config files for TypeScript, Tailwind, Vite, and Drizzle

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: ShadCN UI component library with Radix UI primitives
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite with custom configuration for development and production

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Express sessions with PostgreSQL store
- **API Structure**: RESTful API with structured error handling
- **Development**: Custom middleware for request logging and error handling

### Database Schema
- **Users Table**: Basic user management (id, username, password)
- **Contact Messages Table**: Stores form submissions (id, firstName, lastName, email, subject, message, createdAt)
- **Schema Management**: Drizzle Kit for migrations and schema management

## Data Flow

1. **Frontend to Backend**: React components use TanStack Query to make API requests to Express.js endpoints
2. **Form Submissions**: Contact form data is validated using Zod schemas before submission
3. **Database Operations**: Express routes use the storage layer to interact with PostgreSQL via Drizzle ORM
4. **Error Handling**: Structured error responses with appropriate HTTP status codes
5. **Development Logging**: Custom middleware logs API requests with timing and response data

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **drizzle-orm & drizzle-kit**: Modern TypeScript ORM and migration tool
- **@tanstack/react-query**: Server state management for React
- **wouter**: Lightweight React router
- **zod**: Runtime type validation and schema validation

### UI and Styling
- **@radix-ui/***: Comprehensive primitive components for accessibility
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for components
- **lucide-react**: Modern icon library

### Development Tools
- **vite**: Fast build tool and development server
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds the React application to `dist/public`
2. **Backend Build**: esbuild bundles the Express.js server to `dist/index.js`
3. **Database**: Drizzle Kit manages schema migrations using `db:push` command

### Environment Configuration
- **Development**: Uses Vite dev server with HMR and Express API proxy
- **Production**: Serves static files from Express with built React app
- **Database**: Requires `DATABASE_URL` environment variable for PostgreSQL connection

### Scripts
- `dev`: Start development server with hot reload
- `build`: Build both frontend and backend for production
- `start`: Start production server
- `db:push`: Push database schema changes

The application is designed to be deployed on platforms that support Node.js and PostgreSQL, with particular optimization for Replit's environment through custom Vite plugins and development tooling.